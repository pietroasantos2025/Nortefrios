# Norte Frios — site institucional e catálogo B2B

Site estático responsivo, em português do Brasil, com páginas Início, Produtos, A Empresa, Parceiros e Contato.

## Como visualizar

Abra `index.html` em um servidor estático local (recomendado) ou publique a pasta inteira em hospedagem estática. Ex.: GitHub Pages, Netlify, Vercel ou hospedagem própria. O catálogo é carregado de `products.json`, portanto não abra como `file://` se o navegador bloquear `fetch`.

## Conteúdo e edição

- `products.json`: catálogo extraído do PDF fornecido, com nome, marca, código, apresentação, categoria e imagem.
- `assets/products/`: recortes das imagens dos produtos retirados das páginas do catálogo original.
- `assets/logo-norte-frios.png`: arquivo de logo enviado, mantido sem redesenho.
- `assets/hero-food.webp`: fotografia criada para a área principal.
- `assets/app.js`: dados de contato, navegação, filtros, lista de cotação e textos de mensagem.
- `assets/style.css`: identidade visual, cores, tipografia e responsividade.

## Alterações rápidas

Edite `CONFIG` no início de `assets/app.js` para trocar o WhatsApp, e-mail e ativar/desativar o banner opcional. O banner está desativado por padrão.

## Observações antes de publicar

1. O formulário de contato abre o aplicativo de e-mail do visitante com a mensagem pronta (mailto). Para envio direto e silencioso ao e-mail da empresa, conecte um endpoint/backend ou serviço de formulários e substitua o handler em `initContact()`.
2. A cotação é enviada ao WhatsApp pelo link oficial `wa.me`, com nome da empresa, códigos, apresentações e quantidades.
3. O catálogo não exibe preços. Confirme disponibilidade e apresentação com a equipe comercial.
4. Endereço, CNPJ e horário não foram inventados nem exibidos.
5. A contagem de 19+ anos é calculada a partir da fundação em 2006 e do ano corrente de 2026; se publicar após 2026, atualize o destaque.
6. As categorias do catálogo foram organizadas nas nove categorias solicitadas. Itens de frango e camarão foram agrupados em Congelados; os nomes e códigos foram preservados conforme a leitura do PDF.

## Escopo do catálogo desta versão

Foram cadastrados 90 itens identificados no catálogo fornecido, distribuídos nas nove categorias do briefing. O PDF disponibilizado para download foi otimizado para web (de aproximadamente 54 MB para cerca de 3 MB). Como o catálogo não informa datas de lançamento por produto, o site evita rotular itens como lançamentos recentes sem confirmação.


## Atualização com foco em pizzarias

A página inicial foi reposicionada para destacar pizzarias como foco comercial atual. As 90 imagens do catálogo foram recortadas para remover a moldura do PDF e ampliar a área útil do produto. Quatro embalagens principais usam imagens de anúncios de produto encontrados online (Monte Castelo, Ceratti, Motasa e Bem Brasil), com fallback local caso o servidor externo não carregue. Antes do uso comercial definitivo, confirme a autorização de uso das imagens com os respectivos titulares/fornecedores.
